# ExmoAPI
ExmoAPI is C# interface for Exmo exchange https://exmo.com (https://exmo.me) 

